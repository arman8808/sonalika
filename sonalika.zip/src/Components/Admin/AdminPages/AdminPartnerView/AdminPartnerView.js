import React from 'react'
import './AdminPartnerView.css'
function AdminPartnerView() {
  return (
    <div>AdminPartnerView</div>
  )
}

export default AdminPartnerView