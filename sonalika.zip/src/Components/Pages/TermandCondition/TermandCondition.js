import React from "react";
import "./TermandCondition.css";
import UpperNavBar from "../../Layout/UpperNavBar/UpperNavBar";
import MainNavBar from "../../Layout/MainNavBar/MainNavBar";
function TermandCondition() {
  return (
    <>
     <UpperNavBar />
    <MainNavBar />
    <div className="termandcondition">
      <div className="termandcondition_heading">
        <h3>Terms & conditions</h3>
        <p>Update June 19 , 2023</p>
      </div>
      <div className="termandcondition_details">
        <p>These Terms & Conditions constitute a binding legal agreement between you (the “User”) and us (the “Company”). By accessing, downloading, and/or using the Service, or any portion thereof, you accept and agree to be bound by these Terms & Conditions. If you do not agree to the terms of this agreement, you must not use the Service. We reserve the right to change the Terms & Conditions without prior notice and it is your responsibility to check this page from time to time for changes. Your continued use of the Service following the posting of changes will mean that you accept and agree to the revisions. The Service is provided to you for your personal, non-commercial use only. You may not modify, reproduce, distribute, create derivative works or adaptations of, publicly display or in any way exploit any of the Content in whole or in part, except as expressly authorized by us.</p>
      <p>These Terms & Conditions constitute a binding legal agreement between you (the “User”) and us (the “Company”). By accessing, downloading, and/or using the Service, or any portion thereof, you accept and agree to be bound by these Terms & Conditions. If you do not agree to the terms of this agreement, you must not use the Service. We reserve the right to change the Terms & Conditions without prior notice and it is your responsibility to check this page from time to time for changes. Your continued use of the Service following the posting of changes will mean that you accept and agree to the revisions. The Service is provided to you for your personal, non-commercial use only. You may not modify, reproduce, distribute, create derivative works or adaptations of, publicly display or in any way exploit any of the Content in whole or in part, except as expressly authorized by us.</p>
      <p>These Terms & Conditions constitute a binding legal agreement between you (the “User”) and us (the “Company”). By accessing, downloading, and/or using the Service, or any portion thereof, you accept and agree to be bound by these Terms & Conditions. If you do not agree to the terms of this agreement, you must not use the Service. We reserve the right to change the Terms & Conditions without prior notice and it is your responsibility to check this page from time to time for changes. Your continued use of the Service following the posting of changes will mean that you accept and agree to the revisions. The Service is provided to you for your personal, non-commercial use only. You may not modify, reproduce, distribute, create derivative works or adaptations of, publicly display or in any way exploit any of the Content in whole or in part, except as expressly authorized by us.</p>
      <p>These Terms & Conditions constitute a binding legal agreement between you (the “User”) and us (the “Company”). By accessing, downloading, and/or using the Service, or any portion thereof, you accept and agree to be bound by these Terms & Conditions. If you do not agree to the terms of this agreement, you must not use the Service. We reserve the right to change the Terms & Conditions without prior notice and it is your responsibility to check this page from time to time for changes. Your continued use of the Service following the posting of changes will mean that you accept and agree to the revisions. The Service is provided to you for your personal, non-commercial use only. You may not modify, reproduce, distribute, create derivative works or adaptations of, publicly display or in any way exploit any of the Content in whole or in part, except as expressly authorized by us.</p>
      <p>These Terms & Conditions constitute a binding legal agreement between you (the “User”) and us (the “Company”). By accessing, downloading, and/or using the Service, or any portion thereof, you accept and agree to be bound by these Terms & Conditions. If you do not agree to the terms of this agreement, you must not use the Service. We reserve the right to change the Terms & Conditions without prior notice and it is your responsibility to check this page from time to time for changes. Your continued use of the Service following the posting of changes will mean that you accept and agree to the revisions. The Service is provided to you for your personal, non-commercial use only. You may not modify, reproduce, distribute, create derivative works or adaptations of, publicly display or in any way exploit any of the Content in whole or in part, except as expressly authorized by us.</p>
      </div>
    </div>
    
    </>
   
  );
}

export default TermandCondition;
